//
//  TableViewList.swift
//  tableView
//
//  Created by Yezan Baba on 02/11/2019.
//  Copyright © 2019 Yezan Baba. All rights reserved.
//

import UIKit

class TableViewList: UIViewController {
    
    let countriesList = ["UK", "USA", "Yeman", "Canada", "Australia"]
    
    @IBOutlet weak var tableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        // This is for rounded corners
        tableView.layer.cornerRadius = 15
        tableView.layer.maskedCorners = [.layerMinXMinYCorner, .layerMaxXMinYCorner]
        
    }
}


// MARK: - Table view data source
extension TableViewList: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return countriesList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        cell.textLabel?.text = countriesList[indexPath.row]
        
        return cell
    }
    
}

